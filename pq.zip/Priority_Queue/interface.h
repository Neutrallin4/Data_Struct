#pragma once
#include <iostream>

#include "main_structure.h"

using namespace std;

void interface()
{
    int indicate = 0;
    while (true)
    {
        cout << "1 - Implementation 1\n2 - Implementation 2\n3 - Implementation 3\n";
        cout << "4 - Implementation 4\n5 - Implementation 5\n0 - Exit\n:";
        cin >> indicate;
        
    }
}
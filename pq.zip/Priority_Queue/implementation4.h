#pragma once
#include "main_structure.h"

using namespace std;

template <class T, int MAX>
class Implementation4       // Insert: Always sorted manner - Remove: rear
{
private:
    T data_arr[MAX];
    int rear = 0;
    bool is_ascending = false;

public:
    Implementation4();

    Implementation4(bool order = false);

    bool is_empty();

    bool is_full();

    bool insert(T);

    T del();

    void display();
};

DECLARE(, Implementation4)
Implementation4() {}

DECLARE(, Implementation4)
Implementation4(bool order) : is_ascending(order) {}

DECLARE(bool, Implementation4)
is_empty() { return (rear == 0 ? true : false); }

DECLARE(bool, Implementation4)
is_full() { return (rear == MAX ? true : false); }

DECLARE(bool, Implementation4)
insert(T data)
{
    if (is_full())
    {
        cout << "Queue is full. Insertion failed" << endl;
        return false;
    }

    // Add the value and increase the rear
    for (int i = rear - 1; i >= 0; i--)
        if (compare(data_arr[i], data, is_ascending))
            data_arr[i + 1] = data[i];
        else
        {
            data_arr[i + 1] = data;
            rear++;
            return true;
        }
    data_arr[0] = data;
    rear++;
    return true;
}

DECLARE(T, Implementation4)
del()
{
    if (is_empty())
    {
        cout << "Queue is empty. Panic imminent" << endl;
        exit(0);
    }
    // Return rear
    return data_arr[--rear];
}

DECLARE(void, Implementation4)
display()
{
    cout << "Diaplaying Implementation 4 Queue:" << endl;
    for (int i = 0; i < rear - 1; i++)
        cout << data_arr[i] << " - ";
    cout << data_arr[rear - 1] << endl;
}
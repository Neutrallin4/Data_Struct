#include <iostream>

#include "main_structure.h"

using namespace std;

int main()
{
    Implementation1<int, 10> test;
    cout << test.is_empty() << endl;
    return 0;
}
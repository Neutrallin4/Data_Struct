#include <iostream>

// Define the macro for member functions (without constructor)
#define DECLARE(type, class_name) \
template <class T, int MAX> \
type class_name<T, MAX>::

// Template class definition
template <class T, int MAX>
class MyClass {
public:
    T data[MAX];  // Data array
    
    // Constructor declaration
    MyClass();  // Constructor declaration

    // Member function to get data
    T getData(int index);
};

// Constructor definition (special case without type)
template <class T, int MAX>
MyClass<T, MAX>::MyClass() {
    // Initialize the array with default values (e.g., setting each element to zero)
    for (int i = 0; i < MAX; ++i) {
        data[i] = T();  // Using the default constructor of T
    }
}

// Member function definition using the macro
DECLARE(T, MyClass) getData(int index) {
    if (index >= 0 && index < MAX) {
        return data[index];
    }
    return T();  // Return default-constructed value of T if out of bounds
}

int main() {
    // Instantiate MyClass with int type and a MAX of 5
    MyClass<int, 5> myClass;

    // Set some values (e.g., manually or with another function)
    myClass.data[0] = 10;
    myClass.data[1] = 20;

    // Print the data
    std::cout << "Data at index 0: " << myClass.getData(0) << std::endl;
    std::cout << "Data at index 1: " << myClass.getData(1) << std::endl;
    std::cout << "Data at index 4: " << myClass.getData(4) << std::endl;  // Should return 0 (default)

    return 0;
}
